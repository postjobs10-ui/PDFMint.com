# PDFMint full-stack starter

## Included
- Frontend based on the PDFMint India-branded website.
- FastAPI backend for Word/PowerPoint/Excel to PDF using LibreOffice.
- OCR endpoint that renders PDF pages and generates searchable PDFs with Tesseract + Poppler.
- OCR language choices: English (`eng`), Hindi (`hin`), Telugu (`tel`), Tamil (`tam`). The Docker image installs those language packs.

## Run with Docker
1. Install Docker Desktop.
2. Open a terminal in the `backend` folder.
3. Run `docker compose up --build`.
4. Open `http://localhost:8000/health` to check service dependencies.
5. Serve the `frontend` folder from a local web server, for example:
   `python -m http.server 5500 --directory ../frontend`
6. Open `http://localhost:5500`.

The frontend defaults to `http://localhost:8000` for its API. For deployment, set `window.PDFMINT_API_BASE` before the frontend script runs, or change the `PDFMINT_API_BASE` constant to your deployed API URL. Add that frontend origin to `CORS_ORIGINS`.

## Without Docker
Install Python 3.12+, LibreOffice (Writer/Calc/Impress), Tesseract with desired language packs, and Poppler (`pdftoppm` and `pdfunite`). Then:
```bash
pip install -r requirements.txt
uvicorn app:app --host 127.0.0.1 --port 8000
```

## Important production hardening
This is a starter backend, not a fully audited production service. Before public launch:
- Add authentication, request rate limits, queue-based processing and concurrency limits.
- Put a reverse proxy in front with HTTPS and request-size/time limits.
- Scan uploads for malware, isolate workers, and enforce CPU/memory/page-count limits.
- Keep processing temporary files ephemeral; define and test deletion policies.
- Restrict CORS to the real frontend domain.
- Monitor logs without storing document contents.
- Validate LibreOffice/Tesseract outputs and test large, malformed, encrypted and adversarial files.
- Verify licensing and redistribution obligations for all dependencies.
- The OCR flow processes pages individually then merges the PDFs; check page orientation and text-layer quality on your test set.
