# PDFMint — India-branded PDF tools website + backend

This package contains:
- `frontend/index.html`: PDFMint website.
- `backend/app.py`: FastAPI conversion/OCR API.
- Docker configuration with LibreOffice, Tesseract and Poppler dependencies.

See `frontend/README.md` for setup and production hardening notes.
