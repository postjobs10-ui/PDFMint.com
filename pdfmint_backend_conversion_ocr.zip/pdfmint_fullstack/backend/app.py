import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Annotated

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from starlette.background import BackgroundTask

APP_NAME = "PDFMint Conversion API"
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "40"))
MAX_UPLOAD_BYTES = MAX_UPLOAD_MB * 1024 * 1024
ALLOWED_OFFICE_EXTENSIONS = {
    ".doc", ".docx", ".odt", ".rtf",
    ".ppt", ".pptx", ".odp",
    ".xls", ".xlsx", ".ods", ".csv",
}
OCR_LANGUAGES = {"eng", "hin", "tel", "tam", "urd"}

app = FastAPI(title=APP_NAME, version="1.0.0")

origins = os.getenv("CORS_ORIGINS", "http://localhost:5500,http://127.0.0.1:5500,http://localhost:8080").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[origin.strip() for origin in origins if origin.strip()],
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)

def require_program(name: str) -> str:
    path = shutil.which(name)
    if not path:
        raise HTTPException(status_code=503, detail=f"Server dependency '{name}' is not installed.")
    return path

async def save_upload(upload: UploadFile, folder: Path, allowed: set[str]) -> Path:
    filename = Path(upload.filename or "upload").name
    suffix = Path(filename).suffix.lower()
    if suffix not in allowed:
        raise HTTPException(status_code=415, detail=f"Unsupported file type: {suffix or 'no extension'}.")
    target = folder / f"input{suffix}"
    size = 0
    with target.open("wb") as dest:
        while True:
            chunk = await upload.read(1024 * 1024)
            if not chunk:
                break
            size += len(chunk)
            if size > MAX_UPLOAD_BYTES:
                raise HTTPException(status_code=413, detail=f"File exceeds the {MAX_UPLOAD_MB} MB limit.")
            dest.write(chunk)
    if size == 0:
        raise HTTPException(status_code=400, detail="The uploaded file is empty.")
    return target

def cleanup_dir(path: str) -> None:
    shutil.rmtree(path, ignore_errors=True)

def run_command(command: list[str], timeout: int = 180) -> None:
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=timeout, check=False)
    except subprocess.TimeoutExpired:
        raise HTTPException(status_code=408, detail="Processing timed out. Try a smaller file.")
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "Processing failed.")[-1200:]
        raise HTTPException(status_code=422, detail=f"Processing failed: {detail}")

def office_to_pdf_endpoint(label: str):
    async def endpoint(file: UploadFile = File(...)):
        temp = tempfile.mkdtemp(prefix="pdfmint-convert-")
        try:
            input_path = await save_upload(file, Path(temp), ALLOWED_OFFICE_EXTENSIONS)
            out_dir = Path(temp) / "out"
            out_dir.mkdir()
            libreoffice = require_program("libreoffice")
            run_command([
                libreoffice, "-env:UserInstallation=file://" + str(Path(temp) / "lo-profile"),
                "--headless", "--convert-to", "pdf", "--outdir", str(out_dir), str(input_path)
            ], timeout=180)
            result = out_dir / f"{input_path.stem}.pdf"
            if not result.exists():
                raise HTTPException(status_code=422, detail=f"Could not convert this {label} file.")
            return FileResponse(
                result, media_type="application/pdf",
                filename=f"{input_path.stem}.pdf",
                background=BackgroundTask(cleanup_dir, temp),
            )
        except Exception:
            cleanup_dir(temp)
            raise
    return endpoint

@app.get("/health")
def health():
    return {
        "status": "ok",
        "libreoffice": bool(shutil.which("libreoffice")),
        "tesseract": bool(shutil.which("tesseract")),
        "pdftoppm": bool(shutil.which("pdftoppm")),
    }

app.add_api_route("/convert/word-to-pdf", office_to_pdf_endpoint("Word"), methods=["POST"])
app.add_api_route("/convert/powerpoint-to-pdf", office_to_pdf_endpoint("PowerPoint"), methods=["POST"])
app.add_api_route("/convert/excel-to-pdf", office_to_pdf_endpoint("Excel"), methods=["POST"])

@app.post("/ocr/pdf-to-searchable-pdf")
async def ocr_pdf_to_searchable_pdf(
    file: UploadFile = File(...),
    language: Annotated[str, Form()] = "eng",
):
    if language not in OCR_LANGUAGES:
        raise HTTPException(status_code=400, detail="Unsupported OCR language.")
    temp = tempfile.mkdtemp(prefix="pdfmint-ocr-")
    try:
        input_path = await save_upload(file, Path(temp), {".pdf"})
        tesseract = require_program("tesseract")
        pdftoppm = require_program("pdftoppm")
        output_prefix = str(Path(temp) / "page")
        # Render at 300 DPI for OCR quality. Limit processing time via subprocess timeouts.
        run_command([pdftoppm, "-r", "300", "-png", str(input_path), output_prefix], timeout=180)
        images = sorted(Path(temp).glob("page-*.png"))
        if not images:
            raise HTTPException(status_code=422, detail="No pages could be rendered from this PDF.")
        # Tesseract can create a searchable PDF from rendered images. Multiple pages are merged by output PDF.
        image_list = Path(temp) / "images.txt"
        image_list.write_text("\n".join(str(p) for p in images), encoding="utf-8")
        out_prefix = str(Path(temp) / "searchable")
        run_command([
            tesseract, str(images[0]), out_prefix, "-l", language, "pdf"
        ], timeout=240)
        first_pdf = Path(temp) / "searchable.pdf"
        if len(images) > 1:
            # Generate one searchable PDF per page then merge via pdfunite.
            page_pdfs = [first_pdf]
            for index, image_path in enumerate(images[1:], start=2):
                page_out = Path(temp) / f"page-{index}-ocr"
                run_command([tesseract, str(image_path), str(page_out), "-l", language, "pdf"], timeout=240)
                page_pdfs.append(Path(str(page_out) + ".pdf"))
            pdfunite = require_program("pdfunite")
            merged = Path(temp) / "ocr-output.pdf"
            run_command([pdfunite, *map(str, page_pdfs), str(merged)], timeout=120)
            result = merged
        else:
            result = first_pdf
        return FileResponse(
            result, media_type="application/pdf",
            filename=f"{input_path.stem}-searchable.pdf",
            background=BackgroundTask(cleanup_dir, temp),
        )
    except Exception:
        cleanup_dir(temp)
        raise
